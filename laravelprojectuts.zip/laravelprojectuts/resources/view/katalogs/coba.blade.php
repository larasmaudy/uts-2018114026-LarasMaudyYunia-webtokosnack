@extends('layouts.app')

@section('title', 'cobaaa')

@section('content')
    Urutan ke - {{ $ke }}
@endsection